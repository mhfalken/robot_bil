/*
  Michael Hansen 10-2026
  Joystick LED test

  Hardware: 
    ESP32 Lolin32 (lite), w. charger app. 380mA

  Arduino board setup: 
    File->Preferences->Additional Boards Manager URLs: 
      https://espressif.github.io/arduino-esp32/package_esp32_index.json
      http://arduino.esp8266.com/stable/package_esp8266com_index.json

    Tools->Board->esp32->WEMOS LOLIN32 Lite
    Compile and install the missing libraries: Tools->Manage Libraries: 
*/

/*
  1) Code the compile and install missing libraries
  2) Change the WiFi SSID to your own and recompile (TBD 0.0)
  3) Download the code to the ESP32 board

  4) Connect mobilephone to WiFi network "Robot-ESP32-???"
  5) Open browser 192.168.4.1 
  6) Check the serial monitor for joystick data and battery level
*/

#include <WiFi.h>
#include <WebSocketsServer.h>

#define GPIO_LED 22  // On board LED

// *****************************************************************************
// WiFi configuration
const char* apSsid = "Robot-ESP32-???";  // TBD 0.0 Change ??? to your own initials
#include "robot_lib.h"

// *****************************************************************************
// Status

uint8_t VBattProcent()
{
  static int vbat = 100;
  vbat--;
  if (vbat < 0)
    vbat = 100;
  return vbat;
}

void StatusPoll()
{
  static uint32_t updateMs;

  if (millis() > updateMs) {
    updateMs = millis() + 2000; // Next poll

    if (joystick.connected) {
      // Send battery level to mobile
      uint8_t batteryPacket[2] = {0x01, VBattProcent()};
      webSocket.broadcastBIN(batteryPacket, 2);
    }
  }
}

void TestPoll()
{
  static uint32_t updateMs;

  if (millis() > updateMs) {
    updateMs = millis() + 2000; // Next poll

    if (joystick.connected) {
      printf("Joystick: X=%4d  Y=%4d  [%i-%i-%i-%i]\n",
        joystick.x, joystick.y, joystick.btn1, joystick.btn2, joystick.btn3, joystick.btn4);

      if (joystick.btn1) {
        digitalWrite(GPIO_LED, LOW);
      }
      else {
        digitalWrite(GPIO_LED, HIGH);
      }
    }
  }
}


// *****************************************************************************
// Main setup and loop

void setup()
{
  Serial.begin(115200);
  delay(2000);  // Wait for serial

  printf("\n\n====================================\n");
  printf("Joystick LED test: %s, %s\n", __DATE__, __TIME__);
  pinMode(GPIO_LED, OUTPUT);
  JoystickSetup();
}

#define LOOP_minMs 10

void loop()
{
  uint32_t timerMs=1500;  // Avoid first loop print warning
  int32_t tt;

  for (;;) {
    JoystickPoll();
    StatusPoll();
    TestPoll();
    tt = millis()-timerMs;
    if (tt > 0)
      printf("LoopTime: %i\n", millis()-(timerMs-LOOP_minMs));
    //printf("Looptime:%i\n", tt);
    while (millis() < timerMs)
      ;
    timerMs = millis() + LOOP_minMs;
  }
}