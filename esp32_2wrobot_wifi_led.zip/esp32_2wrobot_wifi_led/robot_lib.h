/* This is an INCLUDE file for the joystick LED test
   Made by Michael Hansen 9-2026 and ChatGPT (joystick and web page code)
*/
WiFiServer server(80);
WebSocketsServer webSocket(81);

#define sgn(x) ((x) < 0 ? -1 : ((x) > 0 ? 1 : 0))

typedef struct {
  bool connected;
  int x, y;
  bool btn1;
  bool btn2;
  bool btn3;
  bool btn4;
} joystick_t;

joystick_t joystick;


// ==================================================
// Robot command
// ==================================================

void RobotCommand(int8_t x, int8_t y, uint8_t buttons)
{
  // x       = -100 ... +100
  // y       = -100 ... +100
  // buttons = button bit mask
  //
  // bit 0 = button 1
  // bit 1 = button 2
  // bit 2 = button 3
  // bit 3 = button 4
  //printf("X=%4d  Y=%4d  Buttons=0x%02X\n", x, y, buttons);

  joystick.x = x;
  joystick.y = y;
  joystick.btn1 = (buttons & 0x01) != 0;
  joystick.btn2 = (buttons & 0x02) != 0;
  joystick.btn3 = (buttons & 0x04) != 0;
  joystick.btn4 = (buttons & 0x08) != 0;
}


// ==================================================
// Web page
// ==================================================

const char webpage[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html lang="da">
<head>
<meta name="viewport" content="width=device-width,initial-scale=1.0,
maximum-scale=1.0,user-scalable=no">
<title>Robot Controller</title>
<style>
html,body {
  margin:0;
  padding:0;
  width:100%;
  height:100%;
  overflow:hidden;
  background:#111;
  color:white;
  font-family:Arial,sans-serif;
  touch-action:none;
  user-select:none;
}
#topbar {
  height:50px;
  display:flex;
  align-items:center;
  justify-content:space-between;
  padding:0 15px;
  box-sizing:border-box;
  background:#222;
}
#status {
  font-size:15px;
}
#battery {
  font-size:15px;
}
#controller {
  position:relative;
  width:100%;
  height:calc(100% - 50px);
  overflow:hidden;
}
#joystick {
  position:absolute;
  left:30px;
  bottom:30px;
  width:160px;
  height:160px;
  border-radius:50%;
  background:#292929;
  border:4px solid #555;
  box-sizing:border-box;
  touch-action:none;
}
#joystick::after {
  content:"";
  position:absolute;
  left:50%;
  top:50%;
  width:95px;
  height:95px;
  transform:translate(-50%,-50%);
  border-radius:50%;
  border:2px solid #444;
  box-sizing:border-box;
  pointer-events:none;
}
#stick {
  position:absolute;
  left:50%;
  top:50%;
  width:70px;
  height:70px;
  transform:translate(-50%,-50%);
  border-radius:50%;
  background:#777;
  border:4px solid #aaa;
  box-sizing:border-box;
  box-shadow:0 3px 8px rgba(0,0,0,0.5);
  pointer-events:none;
}
#buttons {
  position:absolute;
  right:30px;
  bottom:30px;
  display:grid;
  grid-template-columns:80px 80px;
  grid-template-rows:80px 80px;
  gap:18px;
}
.button {
  width:80px;
  height:80px;
  border-radius:50%;
  border:4px solid #555;
  background:#292929;
  display:flex;
  align-items:center;
  justify-content:center;
  font-size:21px;
  font-weight:bold;
  box-sizing:border-box;
  touch-action:none;
  box-shadow:0 3px 8px rgba(0,0,0,0.5);
}
.button.active {
  background:#777;
  border-color:#aaa;
  transform:scale(0.96);
}
</style>
</head>
<body>
<div id="topbar">
  <div id="status">Forbinder...</div>
  <div id="battery">🔋 --%</div>
</div>
<div id="controller">
  <div id="joystick">
    <div id="stick"></div>
  </div>
  <div id="buttons">
    <div class="button" data-button="0">1</div>
    <div class="button" data-button="1">2</div>
    <div class="button" data-button="2">3</div>
    <div class="button" data-button="3">4</div>
  </div>
</div>
<script>
let socket = null;
let joystickX = 0;
let joystickY = 0;
let buttons = 0;
const deadZone = 5;
let joystickTouch = null;

function ConnectWebSocket()
{
  socket = new WebSocket("ws://" + location.hostname + ":81");
  socket.binaryType = "blob";
  socket.onopen = function() {
    document.getElementById("status").textContent = "Forbundet";
  };
  socket.onclose = function() {
    document.getElementById("status").textContent = "Afbrudt";
    setTimeout(ConnectWebSocket, 1000);
  };
  socket.onerror = function() {
    document.getElementById("status").textContent = "Fejl";
  };
  socket.onmessage = function(event) {
    if (!(event.data instanceof Blob)) return;
    event.data.arrayBuffer().then(function(buffer) {
      const data = new Uint8Array(buffer);
      if (data.length >= 2 && data[0] === 0x01) {
        document.getElementById("battery").textContent =
          "🔋 " + data[1] + "%";
      }
    });
  };
}

function ApplyDeadZone(value)
{
  if (Math.abs(value) <= deadZone) return 0;
  if (value > 0) {
    return Math.round(((value - deadZone) /
      (100 - deadZone)) * 100);
  }
  return Math.round(((value + deadZone) /
    (100 - deadZone)) * 100);
}

function UpdateJoystick(clientX, clientY)
{
  const rect = document.getElementById("joystick").getBoundingClientRect();
  const centerX = rect.left + rect.width / 2;
  const centerY = rect.top + rect.height / 2;
  let dx = clientX - centerX;
  let dy = clientY - centerY;
  const maxDistance = rect.width / 2 - 39;
  const distance = Math.sqrt(dx * dx + dy * dy);
  if (distance > maxDistance) {
    dx = dx / distance * maxDistance;
    dy = dy / distance * maxDistance;
  }
  const rawX = Math.round((dx / maxDistance) * 100);
  const rawY = Math.round((-dy / maxDistance) * 100);
  joystickX = ApplyDeadZone(rawX);
  joystickY = ApplyDeadZone(rawY);
  const stick = document.getElementById("stick");
  stick.style.left = (50 + (dx / maxDistance) * 50) + "%";
  stick.style.top = (50 + (dy / maxDistance) * 50) + "%";
}

function ResetJoystick()
{
  joystickX = 0;
  joystickY = 0;
  const stick = document.getElementById("stick");
  stick.style.left = "50%";
  stick.style.top = "50%";
}

const joystick = document.getElementById("joystick");

joystick.addEventListener("touchstart", function(event) {
  event.preventDefault();
  if (joystickTouch !== null) return;
  const touch = event.changedTouches[0];
  joystickTouch = touch.identifier;
  UpdateJoystick(touch.clientX, touch.clientY);
}, { passive:false });

joystick.addEventListener("touchmove", function(event) {
  event.preventDefault();
  for (const touch of event.changedTouches) {
    if (touch.identifier === joystickTouch) {
      UpdateJoystick(touch.clientX, touch.clientY);
      break;
    }
  }
}, { passive:false });

joystick.addEventListener("touchend", function(event) {
  for (const touch of event.changedTouches) {
    if (touch.identifier === joystickTouch) {
      joystickTouch = null;
      ResetJoystick();
      break;
    }
  }
});

joystick.addEventListener("touchcancel", function() {
  joystickTouch = null;
  ResetJoystick();
});

document.querySelectorAll(".button").forEach(function(button) {
  const index = parseInt(button.dataset.button);
  button.addEventListener("touchstart", function(event) {
    event.preventDefault();
    buttons |= 1 << index;
    button.classList.add("active");
  }, { passive:false });
  button.addEventListener("touchend", function(event) {
    event.preventDefault();
    buttons &= ~(1 << index);
    button.classList.remove("active");
  }, { passive:false });
  button.addEventListener("touchcancel", function() {
    buttons &= ~(1 << index);
    button.classList.remove("active");
  });
});

function SendCommand()
{
  if (!socket || socket.readyState !== WebSocket.OPEN) return;
  const packet = new Uint8Array(3);
  packet[0] = joystickX & 0xFF;
  packet[1] = joystickY & 0xFF;
  packet[2] = buttons;
  socket.send(packet);
}

ConnectWebSocket();
setInterval(SendCommand, 33);
</script>
</body>
</html>
)rawliteral";


// ==================================================
// WebSocket event
// ==================================================

void WebSocketEvent(uint8_t num, WStype_t type, uint8_t* payload,
                    size_t length)
{
  if (type == WStype_CONNECTED) {
    printf("\n================================\n");
    printf("Mobile connected\n");
    printf("================================\n");

    //uint8_t batteryPacket[2] = {0x01, GetBatteryLevel()};
    //webSocket.sendBIN(num, batteryPacket, 2);
    joystick.connected = true;
  }

  if (type == WStype_DISCONNECTED) {
    printf("\nMobile disconnected\n");
    RobotCommand(0, 0, 0);
    joystick.connected = false;
  }

  if (type == WStype_BIN && length == 3) {
    int8_t x = (int8_t)payload[0];
    int8_t y = (int8_t)payload[1];
    uint8_t buttons = payload[2];
    RobotCommand(x, y, buttons);
  }
}


// ==================================================
// Setup
// ==================================================

void JoystickSetup()
{
  //printf("Mobile Joystick Controller\n");

  WiFi.mode(WIFI_AP);
  WiFi.softAP(apSsid);

  printf("WiFi SSID: %s\n", apSsid);
  printf("IP address: %s\n", WiFi.softAPIP().toString().c_str());

  server.begin();
  webSocket.begin();
  webSocket.onEvent(WebSocketEvent);

  //printf("WebSocket started\n");
  //printf("Waiting for mobile...\n\n");
}


// ==================================================
// Main loop
// ==================================================

void JoystickPoll()
{
  webSocket.loop();

  WiFiClient client = server.available();

  if (client) {
    String request = "";
    unsigned long timeout = millis() + 1000;

    while (client.connected() && millis() < timeout) {
      if (client.available()) {
        char c = client.read();
        request += c;
        if (request.endsWith("\r\n\r\n")) break;
      }
    }

    client.println("HTTP/1.1 200 OK");
    client.println("Content-Type: text/html; charset=utf-8");
    client.println("Connection: close");
    client.println();
    client.print(webpage);
    client.stop();
  }

  static bool wasConnected = false;
  bool connected = WiFi.softAPgetStationNum() > 0;

  if (!connected) {
    if (wasConnected) {
      printf("FAILSAFE: No mobile connected\n");
      RobotCommand(0, 0, 0);
    }
  }

  wasConnected = connected;
}
