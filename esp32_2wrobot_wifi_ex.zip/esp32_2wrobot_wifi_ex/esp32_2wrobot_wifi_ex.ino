/*
  Michael Hansen 9-2026
  2 wheel robot - tutorial project

  Hardware: 
    ESP32 Lolin32 (lite), w. charger app. 380mA
    TFT Color Display
    2 motors 

  Arduino board setup: 
    File->Preferences->Additional Boards Manager URLs: 
      https://espressif.github.io/arduino-esp32/package_esp32_index.json
      http://arduino.esp8266.com/stable/package_esp8266com_index.json

    Tools->Board->esp32->WEMOS LOLIN32 Lite
    Compile and install the missing libraries: Tools->Manage Libraries: 
*/

/*
Challenge #0
  Install missing libraries etc and get the code to compile
  Change the WiFi SSID to your own and recompile (TBD 0.0)
  Download the code to the car, connect mobile and see the car can move

Challenge #1
  Fix motor controller: TBD 1.x

Challenge #2
  Fix voltage reading: TBD 2.x

Challenge #3
  Solder NEO pixels to the car and see it is working
  Update NEO pixels: TBD 3.x

Challenge #4
  Attach a TFT display to the car and see it is working
  Update display: TBD 4.x

Challenge #5
  Use at least one of the mobile buttons to control something on the car
*/

#include <Wire.h>
#include <Adafruit_NeoPixel.h>
//#include <ESP32Servo.h>
//#include <SparkFun_VL53L1X.h>
#include <Adafruit_GFX.h>     // Core graphics library
#include <Adafruit_ST7789.h>  // Hardware-specific library for ST7789
#include <esp_task_wdt.h>
#include <ESP32AnalogRead.h>
#include <WiFi.h>
#include <WebSocketsServer.h>

// *****************************************************************************
// WiFi configuration
const char* apSsid = "Robot-ESP32-???";  // TBD 0.0 Change to your own SSID (include initials) 

// *****************************************************************************
// TFT Display

// color definitions  RGB: xxxx.x xxx.xxx x.xxxx
#define TFT_COLOR_black      0x0000
#define TFT_COLOR_blue       0x001F
#define TFT_COLOR_red        0xF800
#define TFT_COLOR_green      0x07E0
#define TFT_COLOR_yellow     0xFFE0
#define TFT_COLOR_gray       0x39E7
#define TFT_COLOR_white      0xFFFF

// tft.fillScreen(TFT_COLOR_black);     # Clear screen
// tft.setTextColor(color);             # Set text color
// tft.setTextSize(2);                  # Set text size 1-5
// tft.setCursor(x, y);                 # Move curser
// tft.drawLine(x1, y1, x2, y2, color); # Draw a line (x1, y1) -> (x2, y2)
// tft.drawRect(x, y, dx, dy, color);   # Draw a rectangle
// tft.fillRect(x, y, dx, dy, color);   # Fill a rectangle
// tft.fillCircle(x, y, r, color);      # Fill circle

// GPIO TFT Display
#define TFT_RST             0  // Or set to -1 and connect to Arduino RESET pin
#define TFT_DC              2
#define TFT_CS              5
#define TFT_SCLK           18  // SCL (default)
#define TFT_MOSI           23  // SDA (default)

// *****************************************************************************
// Display setup

Adafruit_ST7789 tft = Adafruit_ST7789(TFT_CS, TFT_DC, TFT_RST); // HW SPI
#include "robot_lib.h"

void TftDisplaySetup()
{
  // TBD 3.0 Setup the TFT display (size, rotation, clear screen etc)
  tft.init(240, 320); 
  tft.fillScreen(TFT_COLOR_black);
  tft.setRotation(3); 
}

// ==================================================
// Battery
// ==================================================

uint8_t VBattProcent()
{
  // TBD 2.0 Fix the battery voltage reading and return the battery level in procent (0-100)
  // Use VBattLevel() -> returns battery voltage in volts (float) [3.2 - 4.2]
  // Ex: vbat = VBattLevel();
  static int procent = 100;
  float vbat;

  procent--;
  if (procent < 0)
    procent = 100;
  return procent;
}

// *****************************************************************************
// Display

void DisplayPoll()
{
  static uint32_t updateMs;
  char txt[10];

  if (millis() > updateMs) {
    updateMs = millis() + 1000; // Next poll

    // TBD 4.6 Make a fancy layout (use lines, rectangles, colors etc)
    // Ex: tft.fillRect(10, 10, 100, 50, TFT_COLOR_blue);

    // TBD 4.1 Change text color
    tft.setTextColor(TFT_COLOR_white);
    // TBD 4.2 Change text size
    tft.setTextSize(2);
    // TBD 4.3 Move text
    tft.setCursor(90, 120);
    // TBD 4.0 Change the text
    tft.print("2 Wheel demo");

    // TBD 4.4 Move the battery level to the top right corner
    // TBD 4.5 Avoid overwritting the text
    tft.setTextSize(2);
    tft.setCursor(100, 200);
    sprintf(txt, "%3.1f", VBattLevel());
    tft.print(txt);
  }
}

// *****************************************************************************
// Motor control

#define MOTOR_right 0
#define MOTOR_left  1

void DrivingPoll()
{
  static uint32_t updateMs;
  int dx, dy, speedL, speedR;

  if (joystick.connected) {
    if (millis() > updateMs) {
      updateMs = millis() + 100; // Next poll
 
      // TBD 1.0 remove printf (2 lines) - comment out when done testing
      printf("Joystick: X=%4d  Y=%4d  [%i-%i-%i-%i]\n",
        joystick.x, joystick.y, joystick.btn1, joystick.btn2, joystick.btn3, joystick.btn4);

      // TBD 1.1 Test both motors are working (forward and backward) with the mobile joystick
      // Fix wires if one or both motors are running in the wrong direction
      dy = joystick.y;  // [-100 to 100]
      // TBD 1.2 Use joystick.x to get the robot to turn left and right (differential drive)
      speedR = dy;
      speedL = dy;
      MotorCtrl(MOTOR_right, speedR);  // speedR are in the range -100 to 100 procent
      MotorCtrl(MOTOR_left, speedL);   // speedL are in the range -100 to 100 procent
    }
  }
}


// *****************************************************************************
// Neopixels

#define LED_cnt   8  // NEO pixels TBD 2.0 update cnt to actual NEO pixels on board
Adafruit_NeoPixel neos(LED_cnt, GPO_neo, NEO_GRB + NEO_KHZ800);

void NeopixelPoll()
{
  static uint32_t updateMs=0;
  static int lastNo=2;
  static bool up=true;

  if (millis() > updateMs) {
    updateMs = millis() + 500; // Next poll
    // TBD 3.1 Turn on the NEO pixels one by one 
    // TBD 3.2 Make some fancy light show
    // TBD 3.0 Change the NEO pixel color to something else (not green)
    neos.setPixelColor(lastNo, neos.Color(0, 50, 0));  // Color is RGB (0-255)
    neos.show();
  }
}


// *****************************************************************************
// Status

void StatusPoll()
{
  static uint32_t updateMs;

  if (millis() > updateMs) {
    updateMs = millis() + 2000; // Next poll

    if (joystick.connected) {
      // Send battery level to mobile
      uint8_t batteryPacket[2] = {0x01, VBattProcent()};
      webSocket.broadcastBIN(batteryPacket, 2);
    }
  }
}


// *****************************************************************************
// Main setup and loop

void setup()
{
  Serial.begin(115200);
  delay(500);  // Wait for serial
  printf("\n\n====================================\n");
  printf("2 Wheel robot: %s, %s\n", __DATE__, __TIME__);
  JoystickSetup();
  HwSetup();
}

#define LOOP_minMs 10

void loop()
{
  uint32_t timerMs=1500;  // Avoid first loop print warning
  int32_t tt;

  TftDisplaySetup();
  //ServoSetup();
  MotorSetup();

  for (;;) {
    JoystickPoll();
    DisplayPoll();
    NeopixelPoll();
    StatusPoll();
    DrivingPoll();
    tt = millis()-timerMs;
    if (tt > 0)
      printf("LoopTime: %i\n", millis()-(timerMs-LOOP_minMs));
    //printf("Looptime:%i\n", tt);
    while (millis() < timerMs)
      ;
    timerMs = millis() + LOOP_minMs;
  }
}