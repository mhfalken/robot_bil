/*
  Michael Hansen 9-2026
  2 wheel robot - tutorial project

  Hardware: 
    ESP32 Lolin32 (lite), w. charger app. 380mA
    TFT Color Display
    2 motors 

  Arduino board setup: 
    File->Preferences->Additional Boards Manager URLs: 
      https://espressif.github.io/arduino-esp32/package_esp32_index.json
      http://arduino.esp8266.com/stable/package_esp8266com_index.json

    Tools->Board->esp32->WEMOS LOLIN32 Lite
    Compile and install the missing libraries: Tools->Manage Libraries: 
*/

/*
Challenge #0
  Install missing libraries etc and get the code to compile
  Change the WiFi SSID in robot_lib.h to your own and recompile (TBD 0.0)
  Download the code to the car, connect mobile and see the car can move (left joystick only is implemented)
Challenge #1
  Fix motor controller: TBD 1.x
Challenge #2
  Update NEO pixels: TBD 2.x
Challenge #3
  Update display: TBD 3.x
Challenge #4
  Use at least one of the mobile buttons to control something on the car
*/

#include <Wire.h>
#include <ESP32Servo.h>
#include <Adafruit_NeoPixel.h>
#include <SparkFun_VL53L1X.h>
#include <Adafruit_GFX.h>     // Core graphics library
#include <Adafruit_ST7789.h>  // Hardware-specific library for ST7789
#include <esp_task_wdt.h>
#include <ESP32AnalogRead.h>
#include <WiFi.h>
#include <WebSocketsServer.h>

// *****************************************************************************
// WiFi configuration
const char* apSsid = "Robot-ESP32";  // TBD 0.0 Change to your own SSID (include initials) 

// *****************************************************************************
// TFT Display

// color definitions  RGB: xxxx.x xxx.xxx x.xxxx
#define TFT_COLOR_black      0x0000
#define TFT_COLOR_blue       0x001F
#define TFT_COLOR_red        0xF800
#define TFT_COLOR_green      0x07E0
#define TFT_COLOR_yellow     0xFFE0
#define TFT_COLOR_gray       0x39E7
#define TFT_COLOR_white      0xFFFF

// tft.fillScreen(TFT_COLOR_black);     # Clear screen
// tft.setTextColor(color);             # Set text color
// tft.setTextSize(2);                  # Set text size 1-5
// tft.setCursor(x, y);                 # Move curser
// tft.drawLine(x1, y1, x2, y2, color); # Draw a line (x1, y1) -> (x2, y2)
// tft.drawRect(x, y, dx, dy, color);   # Draw a rectangle
// tft.fillRect(x, y, dx, dy, color);   # Fill a rectangle
// tft.fillCircle(x, y, r, color);      # Fill circle

// GPIO TFT Display
#define TFT_RST             0  // Or set to -1 and connect to Arduino RESET pin
#define TFT_DC              2
#define TFT_CS              5
#define TFT_SCLK           18  // SCL (default)
#define TFT_MOSI           23  // SDA (default)

// *****************************************************************************
// Display setup

Adafruit_ST7789 tft = Adafruit_ST7789(TFT_CS, TFT_DC, TFT_RST); // HW SPI

void TftDisplaySetup()
{
  // TBD 3.0 Setup the TFT display (size, rotation, clear screen etc)
  tft.init(240, 320); 
  tft.fillScreen(TFT_COLOR_black);
  tft.setRotation(3); 
}

#include "robot_lib.h"

// *****************************************************************************
// Display

void DisplayPoll()
{
  static uint32_t updateMs;
  char txt[10];

  if (millis() > updateMs) {
    updateMs = millis() + 1000; // Next poll

    // TBD 3.4 Make a fancy layout (use lines, rectangles, colors etc)

    // TBD 3.1 Update text and only print once
    tft.setTextColor(TFT_COLOR_white);
    tft.setTextSize(2);
    tft.setCursor(90, 120);
    tft.print("2 Wheel demo");

    // TBD 3.2 Move the battery level to the top right corner
    // TBD 3.3 Avoid overwritting the text
    tft.setTextSize(2);
    tft.setCursor(100, 200);
    sprintf(txt, "%3.1f", VBattLevel());
    tft.print(txt);
  }
}

// *****************************************************************************
// Motor control

#define MOTOR_right 0
#define MOTOR_left  1

void DrivingPoll()
{
  static uint32_t updateMs;
  int dx, dy, speedL, speedR;

  if (joystick.connected) {
    if (millis() > updateMs) {
      updateMs = millis() + 100; // Next poll
 
      // TBD 1.0 remove printf (2 lines)
      printf("Joystick: X=%4d  Y=%4d  [%i-%i-%i-%i]\n",
        joystick.x, joystick.y, joystick.btn0, joystick.btn1, joystick.btn2, joystick.btn3);

      // TBD 1.1 Control motors with mobile joystick (forward, backward, left, right)
      dy = joystick.y;
      speedR = dy;
      speedL = dy;
      MotorCtrl(MOTOR_right, speedR);
      MotorCtrl(MOTOR_left, speedL);
    }
  }
}

// *****************************************************************************
// Neopixels

#define LED_cnt   8  // NEO pixels TBD 2.0 update cnt to actual NEO pixels on board
Adafruit_NeoPixel neos(LED_cnt, GPO_neo, NEO_GRB + NEO_KHZ800);

void NeopixelPoll()
{
  static uint32_t updateMs=0;
  static int lastNo=0;
  static bool up=true;

  if (millis() > updateMs) {
    updateMs = millis() + 200; // Next poll
    // TBD 2.1 Make some fancy light show
    neos.setPixelColor(2, neos.Color(0, 50, 0));  
    neos.show();
  }
}


// *****************************************************************************
// Status

void StatusPoll()
{
  static uint32_t updateMs;

  if (millis() > updateMs) {
    updateMs = millis() + 2000; // Next poll

    if (joystick.connected) {
      // Send battery level to mobile
      uint8_t batteryPacket[2] = {0x01, VBattProcent()};
      webSocket.broadcastBIN(batteryPacket, 2);
    }
  }
}

// *****************************************************************************
// Main setup and loop

void setup()
{
  Serial.begin(115200);
  delay(500);  // Wait for serial
  printf("\n\n====================================\n");
  printf("2 Wheel robot: %s, %s\n", __DATE__, __TIME__);
  JoystickSetup();
  HwSetup();
}

#define LOOP_minMs 10

void loop()
{
  uint32_t timerMs=1500;  // Avoid first loop print warning
  int32_t tt;

  TftDisplaySetup();
  ServoSetup();
  MotorSetup();

  for (;;) {
    JoystickPoll();
    DisplayPoll();
    NeopixelPoll();
    StatusPoll();
    DrivingPoll();
    tt = millis()-timerMs;
    if (tt > 0)
      printf("LoopTime: %i\n", millis()-(timerMs-LOOP_minMs));
    //printf("Looptime:%i\n", tt);
    while (millis() < timerMs)
      ;
    timerMs = millis() + LOOP_minMs;
  }
}