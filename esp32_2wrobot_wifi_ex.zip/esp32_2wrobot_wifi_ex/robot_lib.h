/* This is an INCLUDE file for the 2 wheel robot project
   Made by Michael Hansen 9-2026 and ChatGPT (joystick and web page code)
*/
WiFiServer server(80);
WebSocketsServer webSocket(81);

#define sgn(x) ((x) < 0 ? -1 : ((x) > 0 ? 1 : 0))

// GPIOs
#define GPO_neo            22
#define GPO_servo_0        25
#define GPI_vbat           34  // LiPo voltage (R/R)
#define GPIO_iicSda        16 
#define GPIO_iicScl        17 

typedef struct {
  bool connected;
  int x, y;
  bool btn1;
  bool btn2;
  bool btn3;
  bool btn4;
} joystick_t;

joystick_t joystick;

// *****************************************************************************
// Graph

#define ANGLE_DG     10
#define ANGLE_COUNTS 18
const float Pi = 3.14159;
int graphOffsetX, graphOffsetY;
float graphScaleX, graphScaleY;
float GraphDist[ANGLE_COUNTS];

void GraphInit(int xMin, int yMin, int xMax, int yMax)
{
  float f;

  tft.fillScreen(TFT_COLOR_black);
  graphScaleX = xMax - xMin;
  graphScaleX = 320/graphScaleX;
  f = xMax-xMin;
  graphOffsetX = 320*(-xMin/f);

  graphScaleY = yMax - yMin;
  graphScaleY = 240/graphScaleY;
  f = yMax-yMin;
  graphOffsetY = 240*(-yMin/f);
  
  //printf("%i %i %f %f\n", graphOffsetX, graphOffsetY, graphScaleX, graphScaleY);
  tft.fillCircle(graphOffsetX, 240-graphOffsetY, 4, TFT_COLOR_yellow);
  //tft.drawLine()
  for (int i=0; i<ANGLE_COUNTS; i++)
    GraphDist[i]=1000;
}

void GraphPlotXY(float xIn, float yIn, uint16_t color=TFT_COLOR_white)
{
  float x, y;

  x = xIn * graphScaleX + graphOffsetX;
  y = 240 - (yIn * graphScaleY + graphOffsetY);
  if (x>=0 && x<320 && y<240) {
    if (y<1)
      tft.fillCircle(x, 1, 2, color==TFT_COLOR_white?TFT_COLOR_red:color);
    else 
      tft.fillCircle(x, y, 2, color);
  }
}

// Plot and erase old points. v must be in 10. degrees jumps
void GraphPolarVD(float v, float dist)
{
  float dOld;

  dOld = GraphDist[int((v+0.1)/ANGLE_DG)];
  GraphPlotXY(dOld*cos(v*Pi/180), dOld*sin(v*Pi/180), TFT_COLOR_black);
  GraphDist[int((v+0.1)/ANGLE_DG)] = dist;
  GraphPlotXY(dist*cos(v*Pi/180), dist*sin(v*Pi/180));
}

void GraphTest()
{
  GraphInit(-100, -10, 100, 140);
#if 0  
  GraphPlotXY(50, 25);
  GraphPlotXY(120, 125);
  GraphPlotXY(-100, 75);
  for (int i=0; i<5; i++)
    GraphPlotXY(0, i*20);
#endif    

}

// *****************************************************************************
// ADC
ESP32AnalogRead adc;

float VBattLevel()
{
  static uint32_t updateMs;
  static float vbat = -1;
  float vin;

  if (millis() > updateMs) {
    updateMs = millis() + 1000; // Next poll
    vin = adc.readVoltage();  
    vin *= 2;  // Resistors on board
    if (vbat > 0)
      vbat = vbat + 0.3*(vin - vbat);  // Calman filter
    else
      vbat = vin;
    //printf("VBat= %5.2f\n", vbat);
  }
  return vbat;
}

#if 0
uint8_t VBattProcent()
{
  float VBat = VBattLevel();
  int VBatP;
  VBatP = 100*(VBat - 3.2);
  if (VBatP > 100)
    VBatP = 100;
  if (VBatP < 0)
    VBatP = 0;
  return VBatP;
}
#endif

#define SERVO_cnt   2  // Always uses atleast 2 ??? TBD
#if 0
// *****************************************************************************
// Servo

Servo servos[SERVO_cnt];
uint8_t GPO_servo[SERVO_cnt] = {GPO_servo_0};

void ServoSetup()
{
	ESP32PWM::allocateTimer(0);
	ESP32PWM::allocateTimer(1);
	ESP32PWM::allocateTimer(2);
	ESP32PWM::allocateTimer(3);
  for (int i=0; i<SERVO_cnt-1; i++) {  // TBD HACK!!
	  servos[i].setPeriodHertz(50);    // standard 50 hz servo
	  servos[i].attach(GPO_servo[i], 500, 2500); 
    servos[i].write(90);  // Center servo
  }
}
#endif

// *****************************************************************************
// PWM 
#define PWM_FREQ   10000   // 1kHz
#define PWM_cnt        4
uint8_t GPO_pwm[PWM_cnt] = {19, 27, 33, 32}; 

void MotorSetup()
{
  for (int i=0; i<PWM_cnt; i++) {
    // Setup
    pinMode(GPO_pwm[i], OUTPUT);
    ledcSetup(i+SERVO_cnt, PWM_FREQ, 8);   
    ledcAttachPin(GPO_pwm[i], i+SERVO_cnt);
  }
}

void MotorCtrl(int motorNo, int speed)
{
  int motorIndex = 2*motorNo + SERVO_cnt;

  speed = constrain(speed, -100, 100);
  //printf("%i: Speed= %i\n", motorNo, speed);
  if (speed == 0) {
    ledcWrite(motorIndex, 0);
    ledcWrite(motorIndex+1, 0);
  }
  else if (speed > 0) {
    speed = map(speed, 0, 100, 120, 255);
    ledcWrite(motorIndex, 0);
    ledcWrite(motorIndex+1, speed);
  }
  else {
    speed = map(speed, 0, -100, 120, 255);
    ledcWrite(motorIndex+1, 0);
    ledcWrite(motorIndex, speed);
  }
}

#if 0  
// *****************************************************************************
// Distance

SFEVL53L1X distanceSensor;

void DistanceSetup() 
{
  if (distanceSensor.begin() != 0) {
    printf("\n*** VL53L1X is NOT working ***\n\n");
    return;
  }
  printf("VL53L1X is working\n");
  distanceSensor.setIntermeasurementPeriod(12);
  distanceSensor.setTimingBudgetInMs(100);  // 20
  distanceSensor.setDistanceModeShort();
  distanceSensor.startRanging(); //Write configuration bytes to initiate measurement
}

const float scale = 0.1;
bool radarActive = false;

void DistanceSweepTest()
{
  static uint32_t updateMs=0, holddownMs=0;
  static uint8_t pos = 90;  // Center pos
  static bool inc;
  int distance;

  if (gamepadPtr) {
    if ((gamepadPtr->buttons() & GP_BTN_triangle) && (holddownMs < millis())) {
      radarActive = !radarActive;  // Toggle
      tft.fillRect(0, 0, 50, 20, TFT_COLOR_black);
      tft.setTextColor(TFT_COLOR_yellow);
      tft.setTextSize(2);
      tft.setCursor(0, 0);
      if (radarActive) {
        tft.print("AUTO");
      }
      else {
        tft.print("MAN");
      }
      holddownMs = millis() + 500;
    }
    if (radarActive) {
      if (distanceSensor.checkForDataReady()) {
        distance = distanceSensor.getDistance(); //Get the result of the measurement from the sensor in mm
        distanceSensor.clearInterrupt();
        GraphPolarVD(pos, distance/10);
        updateMs = millis();
        if (inc) {
          if (pos <= (170-ANGLE_DG))
            pos += ANGLE_DG;
          else {
            inc = false;
            pos -= ANGLE_DG;
          }
        }
        else {
          if (pos >= ANGLE_DG)
            pos -= ANGLE_DG;
          else {
            inc = true;
            pos += ANGLE_DG;
          }
        }
        servos[0].write(pos);
      }
    }
  }
}
#endif  


// *****************************************************************************
// Setup

void HwSetup()
{
  // Setup I2C Lidar
  Wire.begin(GPIO_iicSda, GPIO_iicScl);
  Wire.setClock(400000);  // 400 kHz

  adc.attach(GPI_vbat);
}


// ==================================================
// Robot command
// ==================================================

void RobotCommand(int8_t x, int8_t y, uint8_t buttons)
{
  // x       = -100 ... +100
  // y       = -100 ... +100
  // buttons = button bit mask
  //
  // bit 0 = button 1
  // bit 1 = button 2
  // bit 2 = button 3
  // bit 3 = button 4
  //printf("X=%4d  Y=%4d  Buttons=0x%02X\n", x, y, buttons);

  joystick.x = x;
  joystick.y = y;
  joystick.btn1 = (buttons & 0x01) != 0;
  joystick.btn2 = (buttons & 0x02) != 0;
  joystick.btn3 = (buttons & 0x04) != 0;
  joystick.btn4 = (buttons & 0x08) != 0;
}


// ==================================================
// Web page
// ==================================================

const char webpage[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html lang="da">
<head>
<meta name="viewport" content="width=device-width,initial-scale=1.0,
maximum-scale=1.0,user-scalable=no">
<title>Robot Controller</title>
<style>
html,body {
  margin:0;
  padding:0;
  width:100%;
  height:100%;
  overflow:hidden;
  background:#111;
  color:white;
  font-family:Arial,sans-serif;
  touch-action:none;
  user-select:none;
}
#topbar {
  height:50px;
  display:flex;
  align-items:center;
  justify-content:space-between;
  padding:0 15px;
  box-sizing:border-box;
  background:#222;
}
#status {
  font-size:15px;
}
#battery {
  font-size:15px;
}
#controller {
  position:relative;
  width:100%;
  height:calc(100% - 50px);
  overflow:hidden;
}
#joystick {
  position:absolute;
  left:30px;
  bottom:30px;
  width:160px;
  height:160px;
  border-radius:50%;
  background:#292929;
  border:4px solid #555;
  box-sizing:border-box;
  touch-action:none;
}
#joystick::after {
  content:"";
  position:absolute;
  left:50%;
  top:50%;
  width:95px;
  height:95px;
  transform:translate(-50%,-50%);
  border-radius:50%;
  border:2px solid #444;
  box-sizing:border-box;
  pointer-events:none;
}
#stick {
  position:absolute;
  left:50%;
  top:50%;
  width:70px;
  height:70px;
  transform:translate(-50%,-50%);
  border-radius:50%;
  background:#777;
  border:4px solid #aaa;
  box-sizing:border-box;
  box-shadow:0 3px 8px rgba(0,0,0,0.5);
  pointer-events:none;
}
#buttons {
  position:absolute;
  right:30px;
  bottom:30px;
  display:grid;
  grid-template-columns:80px 80px;
  grid-template-rows:80px 80px;
  gap:18px;
}
.button {
  width:80px;
  height:80px;
  border-radius:50%;
  border:4px solid #555;
  background:#292929;
  display:flex;
  align-items:center;
  justify-content:center;
  font-size:21px;
  font-weight:bold;
  box-sizing:border-box;
  touch-action:none;
  box-shadow:0 3px 8px rgba(0,0,0,0.5);
}
.button.active {
  background:#777;
  border-color:#aaa;
  transform:scale(0.96);
}
</style>
</head>
<body>
<div id="topbar">
  <div id="status">Forbinder...</div>
  <div id="battery">🔋 --%</div>
</div>
<div id="controller">
  <div id="joystick">
    <div id="stick"></div>
  </div>
  <div id="buttons">
    <div class="button" data-button="0">1</div>
    <div class="button" data-button="1">2</div>
    <div class="button" data-button="2">3</div>
    <div class="button" data-button="3">4</div>
  </div>
</div>
<script>
let socket = null;
let joystickX = 0;
let joystickY = 0;
let buttons = 0;
const deadZone = 5;
let joystickTouch = null;

function ConnectWebSocket()
{
  socket = new WebSocket("ws://" + location.hostname + ":81");
  socket.binaryType = "blob";
  socket.onopen = function() {
    document.getElementById("status").textContent = "Forbundet";
  };
  socket.onclose = function() {
    document.getElementById("status").textContent = "Afbrudt";
    setTimeout(ConnectWebSocket, 1000);
  };
  socket.onerror = function() {
    document.getElementById("status").textContent = "Fejl";
  };
  socket.onmessage = function(event) {
    if (!(event.data instanceof Blob)) return;
    event.data.arrayBuffer().then(function(buffer) {
      const data = new Uint8Array(buffer);
      if (data.length >= 2 && data[0] === 0x01) {
        document.getElementById("battery").textContent =
          "🔋 " + data[1] + "%";
      }
    });
  };
}

function ApplyDeadZone(value)
{
  if (Math.abs(value) <= deadZone) return 0;
  if (value > 0) {
    return Math.round(((value - deadZone) /
      (100 - deadZone)) * 100);
  }
  return Math.round(((value + deadZone) /
    (100 - deadZone)) * 100);
}

function UpdateJoystick(clientX, clientY)
{
  const rect = document.getElementById("joystick").getBoundingClientRect();
  const centerX = rect.left + rect.width / 2;
  const centerY = rect.top + rect.height / 2;
  let dx = clientX - centerX;
  let dy = clientY - centerY;
  const maxDistance = rect.width / 2 - 39;
  const distance = Math.sqrt(dx * dx + dy * dy);
  if (distance > maxDistance) {
    dx = dx / distance * maxDistance;
    dy = dy / distance * maxDistance;
  }
  const rawX = Math.round((dx / maxDistance) * 100);
  const rawY = Math.round((-dy / maxDistance) * 100);
  joystickX = ApplyDeadZone(rawX);
  joystickY = ApplyDeadZone(rawY);
  const stick = document.getElementById("stick");
  stick.style.left = (50 + (dx / maxDistance) * 50) + "%";
  stick.style.top = (50 + (dy / maxDistance) * 50) + "%";
}

function ResetJoystick()
{
  joystickX = 0;
  joystickY = 0;
  const stick = document.getElementById("stick");
  stick.style.left = "50%";
  stick.style.top = "50%";
}

const joystick = document.getElementById("joystick");

joystick.addEventListener("touchstart", function(event) {
  event.preventDefault();
  if (joystickTouch !== null) return;
  const touch = event.changedTouches[0];
  joystickTouch = touch.identifier;
  UpdateJoystick(touch.clientX, touch.clientY);
}, { passive:false });

joystick.addEventListener("touchmove", function(event) {
  event.preventDefault();
  for (const touch of event.changedTouches) {
    if (touch.identifier === joystickTouch) {
      UpdateJoystick(touch.clientX, touch.clientY);
      break;
    }
  }
}, { passive:false });

joystick.addEventListener("touchend", function(event) {
  for (const touch of event.changedTouches) {
    if (touch.identifier === joystickTouch) {
      joystickTouch = null;
      ResetJoystick();
      break;
    }
  }
});

joystick.addEventListener("touchcancel", function() {
  joystickTouch = null;
  ResetJoystick();
});

document.querySelectorAll(".button").forEach(function(button) {
  const index = parseInt(button.dataset.button);
  button.addEventListener("touchstart", function(event) {
    event.preventDefault();
    buttons |= 1 << index;
    button.classList.add("active");
  }, { passive:false });
  button.addEventListener("touchend", function(event) {
    event.preventDefault();
    buttons &= ~(1 << index);
    button.classList.remove("active");
  }, { passive:false });
  button.addEventListener("touchcancel", function() {
    buttons &= ~(1 << index);
    button.classList.remove("active");
  });
});

function SendCommand()
{
  if (!socket || socket.readyState !== WebSocket.OPEN) return;
  const packet = new Uint8Array(3);
  packet[0] = joystickX & 0xFF;
  packet[1] = joystickY & 0xFF;
  packet[2] = buttons;
  socket.send(packet);
}

ConnectWebSocket();
setInterval(SendCommand, 33);
</script>
</body>
</html>
)rawliteral";


// ==================================================
// WebSocket event
// ==================================================

void WebSocketEvent(uint8_t num, WStype_t type, uint8_t* payload,
                    size_t length)
{
  if (type == WStype_CONNECTED) {
    printf("\n================================\n");
    printf("Mobile connected\n");
    printf("================================\n");

    //uint8_t batteryPacket[2] = {0x01, GetBatteryLevel()};
    //webSocket.sendBIN(num, batteryPacket, 2);
    joystick.connected = true;
  }

  if (type == WStype_DISCONNECTED) {
    printf("\nMobile disconnected\n");
    RobotCommand(0, 0, 0);
    joystick.connected = false;
  }

  if (type == WStype_BIN && length == 3) {
    int8_t x = (int8_t)payload[0];
    int8_t y = (int8_t)payload[1];
    uint8_t buttons = payload[2];
    RobotCommand(x, y, buttons);
  }
}


// ==================================================
// Setup
// ==================================================

void JoystickSetup()
{
  //printf("Mobile Joystick Controller\n");

  WiFi.mode(WIFI_AP);
  WiFi.softAP(apSsid);

  printf("WiFi SSID: %s\n", apSsid);
  printf("IP address: %s\n", WiFi.softAPIP().toString().c_str());

  server.begin();
  webSocket.begin();
  webSocket.onEvent(WebSocketEvent);

  //printf("WebSocket started\n");
  //printf("Waiting for mobile...\n\n");
}


// ==================================================
// Main loop
// ==================================================

void JoystickPoll()
{
  webSocket.loop();

  WiFiClient client = server.available();

  if (client) {
    String request = "";
    unsigned long timeout = millis() + 1000;

    while (client.connected() && millis() < timeout) {
      if (client.available()) {
        char c = client.read();
        request += c;
        if (request.endsWith("\r\n\r\n")) break;
      }
    }

    client.println("HTTP/1.1 200 OK");
    client.println("Content-Type: text/html; charset=utf-8");
    client.println("Connection: close");
    client.println();
    client.print(webpage);
    client.stop();
  }

  static bool wasConnected = false;
  bool connected = WiFi.softAPgetStationNum() > 0;

  if (!connected) {
    if (wasConnected) {
      printf("FAILSAFE: No mobile connected\n");
      RobotCommand(0, 0, 0);
    }
  }

  wasConnected = connected;
}


#if 0
// *****************************************************************************
// Distance

void DistancePoll()
{
  static uint32_t updateMs=0;
  int distance;

  if (distanceSensor.checkForDataReady()) {
    distance = distanceSensor.getDistance(); //Get the result of the measurement from the sensor
    distanceSensor.clearInterrupt();
    if (millis() > updateMs) {
      // TBD 4.0 activate distance sensor in main loop and test it is working
      // TBD 4.1 use distance sensor to stop car before it hits a wall (use a global variable)
      updateMs = millis() + 300; // Next poll
      printf("Distance(mm):  %i\n", distance);
    }
  }
  //distanceSensor.stopRanging();
}


// *****************************************************************************
// Servo

void ServoPoll() 
{
  static uint32_t updateMs;
  static uint8_t pos = 90;  // Center pos

  if (millis() > updateMs) {
    updateMs = millis() + 500; // Next poll
    // Move servo from side to side [0-170]
    servos[0].write(pos);
  }
}

#endif